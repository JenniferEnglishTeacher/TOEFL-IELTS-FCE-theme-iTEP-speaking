const descriptivePrompts = [
  {
    category: "People",
    title: "A Teacher Who Influenced You",
    prompt: "Describe a teacher who had a great influence on you.",
    model: "I would like to talk about my junior high school English teacher, Ms. Lin. She had a major impact on me because her classes were always lively and interactive, rather than just memorizing grammar rules. Whenever I made mistakes, she would patiently encourage me to try again without feeling embarrassed. Thanks to her guidance, I gradually built up my confidence in speaking English. She didn't just teach from the textbook; she also shared interesting Western cultural stories, which inspired me to dream about studying abroad in the future.",
    keywords: ["Junior high school", "Have a major impact on", "Lively and interactive", "Memorize grammar rules", "Patiently encourage", "Feel embarrassed", "Thanks to her guidance", "Gradually build up", "Confidence in speaking", "Teach from the textbook", "Western cultural stories", "Inspire someone to", "Study abroad", "Role model", "Passionate about teaching", "Approachable", "Create a positive environment", "Give constructive feedback", "Patient listener", "Shape my character"]
  },
  {
    category: "People",
    title: "Your Best Friend",
    prompt: "Describe your best friend and explain why they are special to you.",
    model: "My best friend is my classmate, Kevin. We have known each other for three years since we entered junior high school. He is a very reliable and humorous person who always knows how to cheer me up when I am feeling down or stressed about exams. What makes him special is that we share many common interests, such as playing basketball and listening to Mandopop. Whenever I face challenges, he is always there to support me and offer great advice. I really treasure our friendship.",
    keywords: ["Classmate", "Known each other", "Reliable person", "Humorous", "Cheer someone up", "Feel down", "Stressed about exams", "Share common interests", "Face challenges", "Support each other", "Offer great advice", "Treasure our friendship", "Through thick and thin", "Trustworthy", "Outgoing personality", "Keep a secret", "Hang out together", "Get along well with", "Count on someone", "Kind-hearted"]
  },
  {
    category: "People",
    title: "A Historical Person",
    prompt: "Describe a famous person from history you would like to meet.",
    model: "If I had the chance, I would really love to meet Mahatma Gandhi. He is an iconic historical figure known worldwide for leading India to independence through non-violent protests. I am truly fascinated by his peaceful philosophy and incredible determination. If I met him, I would ask him how he managed to stay calm and strong when facing such massive political pressure and danger. His life story teaches us that peaceful methods can be more powerful than violence, and I find that deeply inspiring.",
    keywords: ["Had the chance", "Iconic historical figure", "Known worldwide for", "Independence", "Non-violent protest", "Truly fascinated by", "Peaceful philosophy", "Incredible determination", "Manage to stay calm", "Face massive pressure", "Political danger", "Deeply inspiring", "Historical impact", "Fight for justice", "Leadership skills", "Change the world", "Admire his courage", "Leave a legacy", "Selfless leader", "Devote one's life to"]
  },
  {
    category: "People",
    title: "A Family Member You Admire",
    prompt: "Describe a family member you admire the most.",
    model: "The family member I admire the most is my mother. She works a full-time job as an accountant, but she still manages to take excellent care of our family every day. She is incredibly hard-working and organized. No matter how tired she is after work, she always prepares nutritious dinners for us and listens to me talk about my day at school. From her, I have learned the importance of responsibility and time management. She is my ultimate role model in life.",
    keywords: ["Admire the most", "Full-time job", "Accountant", "Manage to do something", "Take excellent care of", "Incredibly hard-working", "Well-organized", "No matter how tired", "Prepare nutritious dinners", "Talk about my day", "Importance of responsibility", "Time management", "Ultimate role model", "Express gratitude", "Unconditional love", "Patient and kind", "Support my dreams", "Balance work and family", "Dedication", "Main pillar of the family"]
  },
  {
    category: "People",
    title: "A Successful Person",
    prompt: "Describe a successful person you know about and why they are successful.",
    model: "I want to describe Ang Lee, the world-famous film director from Taiwan. He is incredibly successful because he has won multiple Academy Awards for movies like Life of Pi. In my opinion, his success comes from his unique ability to combine Eastern culture with Western storytelling techniques. Furthermore, he faced many failures and rejections early in his career, but he never gave up on his dream. His perseverance and passion for filmmaking are the main reasons why he achieved global success.",
    keywords: ["World-famous", "Film director", "Incredibly successful", "Win multiple awards", "Academy Awards", "In my opinion", "Unique ability", "Combine culture", "Storytelling techniques", "Face failures", "Career rejections", "Early in his career", "Never give up on", "Perseverance", "Passion for filmmaking", "Achieve global success", "International recognition", "Overcome obstacles", "Creative vision", "Source of inspiration"]
  },
  {
    category: "People",
    title: "A Helpful Neighbor",
    prompt: "Describe a neighbor who has helped you or your family.",
    model: "Our next-door neighbor, Mr. Wang, is a retired mechanic who is always willing to lend a helping hand. Last summer, during a heavy typhoon, our kitchen ceiling suddenly started leaking water. We were panicking because my parents weren't home. Mr. Wang noticed our situation, immediately came over with his tools, and quickly fixed the problem for us. He refused to take any money for it. Having a helpful and kind neighbor like him makes our community feel safe and warm.",
    keywords: ["Next-door neighbor", "Retired mechanic", "Willing to lend a helping hand", "Heavy typhoon", "Kitchen ceiling", "Leak water", "Panic", "Notice our situation", "Immediately come over", "Fix the problem", "Refuse to take money", "Helpful and kind", "Local community", "Sense of safety", "Warm-hearted", "Good relationship", "Live close by", "Emergency situation", "Do a favor", "Trustworthy neighbor"]
  },
  {
    category: "People",
    title: "An Artist You Like",
    prompt: "Describe an artist, musician, or writer you like.",
    model: "I am a big fan of the Taiwanese singer-songwriter Jay Chou. He is a brilliant musician who changed the Asian pop music industry completely. What I like most about him is his unique style, which blends traditional Chinese musical instruments with modern Western rap and R&B music. His songs always have beautiful melodies and meaningful lyrics that relate to teenage life and historical stories. Listening to his music helps me relax after studying hard, and his creativity constantly inspires me.",
    keywords: ["Big fan of", "Singer-songwriter", "Brilliant musician", "Pop music industry", "Unique style", "Blend traditional elements", "Chinese musical instruments", "Modern Western rap", "Beautiful melodies", "Meaningful lyrics", "Relate to teenage life", "Relax after studying", "Constantly inspire", "Musical talent", "Catchy tunes", "Creative genius", "Pop icon", "Album release", "Express emotions", "Perform on stage"]
  },
  {
    category: "People",
    title: "Someone You Enjoy Spending Time With",
    prompt: "Describe a person you enjoy spending time with.",
    model: "I always enjoy spending time with my older cousin, Eric. He is currently studying engineering at university, so he is very knowledgeable and always tells me interesting facts about science and technology. We love playing video games together on weekends. He is an excellent listener and gives me great practical advice whenever I feel anxious about my upcoming exams or future high school life. Time always flies when we hang out because he is incredibly funny and easy to talk to.",
    keywords: ["Enjoy spending time with", "Older cousin", "Study engineering", "Knowledgeable", "Interesting facts", "Science and technology", "Play video games", "On weekends", "Excellent listener", "Practical advice", "Feel anxious about", "Upcoming exams", "High school life", "Time flies", "Hang out", "Incredibly funny", "Easy to talk to", "Sense of humor", "Positive energy", "Close relationship"]
  },
  {
    category: "Places",
    title: "Your Favorite Room",
    prompt: "Describe your favorite room in your house.",
    model: "My favorite room in my house is definitely my bedroom. It is my personal sanctuary where I can fully relax and be myself. The walls are painted a soothing light blue, and there is a large window that lets in plenty of natural sunlight during the day. In the corner, I have a comfortable desk where I do my homework and read books. I have also decorated the walls with posters of my favorite anime characters. It is the perfect place for me to unwind after a tiring day at school.",
    keywords: ["Favorite room", "Definitely", "Personal sanctuary", "Fully relax", "Painted a soothing color", "Large window", "Natural sunlight", "In the corner", "Comfortable desk", "Do my homework", "Read books", "Decorate the walls", "Favorite anime characters", "Perfect place to unwind", "Tiring day at school", "Cozy bed", "Private space", "Keep things organized", "Peaceful atmosphere", "Feel safe and comfortable"]
  },
  {
    category: "Places",
    title: "A Tourist Attraction",
    prompt: "Describe a famous tourist attraction in your country.",
    model: "A famous tourist attraction in Taiwan that I highly recommend is Taipei 101. Located in the heart of Taipei City, it was once the tallest building in the world. It looks like a giant bamboo stalk, which symbolizes strength and growth in Asian culture. Visitors can take a super-fast elevator to the indoor observation deck on the 89th floor. From there, you can get a spectacular panoramic view of the entire city. It is especially beautiful at night when the city lights up.",
    keywords: ["Tourist attraction", "Highly recommend", "Located in the heart of", "Tallest building", "Giant bamboo stalk", "Symbolize strength", "Asian culture", "Super-fast elevator", "Indoor observation deck", "Spectacular panoramic view", "Entire city", "Especially beautiful at night", "City lights up", "Architectural marvel", "Shopping mall", "Landmark of Taiwan", "Attract millions of visitors", "New Year fireworks", "Urban landscape", "Must-visit place"]
  },
  {
    category: "Places",
    title: "A Beautiful Natural Place",
    prompt: "Describe a beautiful park or natural place you have visited.",
    model: "One of the most beautiful natural places I have visited is Taroko Gorge in Hualien. It is famous for its stunning marble canyons, rushing rivers, and high mountains. When I walked along the trails, I was amazed by the breathtaking scenery created by nature over millions of years. The air there was incredibly fresh and crisp, which made me feel deeply refreshed. It is an ideal escape from the noisy city life, and it taught me to appreciate the wonders of nature.",
    keywords: ["Natural place", "Marble canyons", "Rushing rivers", "High mountains", "Walk along the trails", "Amazed by", "Breathtaking scenery", "Created by nature", "Fresh and crisp air", "Feel deeply refreshed", "Ideal escape", "Noisy city life", "Appreciate nature", "Wonders of nature", "Spectacular views", "Hiking route", "Geological features", "National park", "Peaceful environment", "Take photos"]
  },
  {
    category: "Places",
    title: "A Library or School",
    prompt: "Describe a school or library where you like to study.",
    model: "I enjoy studying at the New Taipei City Public Library. It is a modern, multi-story building with excellent facilities. The study areas are extremely quiet and well-lit, which helps me focus entirely on my textbooks without any distractions. There are comfortable individual desks and free Wi-Fi access for research. Additionally, they have a massive collection of English books, which is helpful for my preparation to study in Singapore. It is definitely my favorite environment for productive learning.",
    keywords: ["Public library", "Modern building", "Multi-story", "Excellent facilities", "Quiet environment", "Well-lit", "Focus entirely on", "Without distractions", "Individual desks", "Free Wi-Fi access", "Massive collection", "Study in Singapore", "Favorite environment", "Productive learning", "Borrow books", "Academic research", "Open to the public", "Strict quiet policy", "Comfortable seating", "Expand knowledge"]
  },
  {
    category: "Places",
    title: "A City You Want to Visit",
    prompt: "Describe an interesting city or town you would like to visit in the future.",
    model: "In the future, I would love to visit Singapore. As an international hub, it is famous for blending modern skyscrapers with lush green gardens, earning it the nickname City in a Garden. I am particularly eager to visit the Marina Bay Sands and the famous Gardens by the Bay to see the giant Supertrees. Furthermore, since Singapore is a multicultural society, I want to try various delicious foods from different cultures, like chicken rice and laksa. It seems like an ideal place to experience both urban growth and nature.",
    keywords: ["Future travel", "International hub", "Blend skyscrapers", "Lush green gardens", "Nickname", "Particularly eager to", "Multicultural society", "Various delicious foods", "Different cultures", "Urban growth", "Experience nature", "Public transport system", "Clean and safe", "Famous landmark", "Advanced city", "Local delicacies", "English-speaking environment", "Tourist destination", "Futuristic architecture", "Broaden my horizons"]
  },
  {
    category: "Places",
    title: "A Restaurant or Cafe",
    prompt: "Describe a restaurant or cafe that you enjoy going to.",
    model: "I love going to a cozy coffee shop near my school called The Green Corner. It has a warm atmosphere with soft acoustic music playing in the background, making it perfect for relaxing. They serve delicious homemade waffles and high-quality milk tea. The staff are always friendly and welcoming. I often go there with my classmates on Friday afternoons to chat about our week and relieve our academic stress. It is a wonderful neighborhood spot with great vibes.",
    keywords: ["Cozy coffee shop", "Warm atmosphere", "Soft acoustic music", "Background music", "Perfect for relaxing", "Serve delicious food", "Homemade waffles", "High-quality milk tea", "Friendly staff", "Welcoming", "Friday afternoons", "Chat about our week", "Relieve academic stress", "Neighborhood spot", "Great vibes", "Reasonable prices", "Comfort food", "Beautifully decorated", "Regular customer", "Hang out with friends"]
  },
  {
    category: "Places",
    title: "A Place to Exercise",
    prompt: "Describe a place where you go to exercise or play sports.",
    model: "I regularly go to the sports center near my house to play badminton and basketball. It is a modern facility equipped with indoor courts, a swimming pool, and a fully functional gym. I prefer exercising there because the indoor courts protect us from bad weather like rain or extreme summer heat. Playing sports there with my friends twice a week helps me stay healthy and physically fit. It is an energetic place filled with active people, which motivates me to exercise harder.",
    keywords: ["Regularly go to", "Sports center", "Play badminton", "Modern facility", "Equipped with", "Indoor courts", "Swimming pool", "Fully functional gym", "Prefer exercising", "Protect from bad weather", "Extreme summer heat", "Twice a week", "Stay healthy", "Physically fit", "Energetic place", "Active people", "Motivate someone to", "Exercise harder", "Workout routine", "Team sports"]
  },
  {
    category: "Objects",
    title: "An Electronic Device",
    prompt: "Describe an important electronic device you use every day.",
    model: "The electronic device I use daily is my smartphone. It is an indispensable tool for my life and studies. I use it for multiple purposes, such as looking up English definitions, communicating with my classmates via messaging apps, and checking bus schedules. Additionally, it has useful educational apps that help me practice my English listening skills. Although it can sometimes be a distraction, it is incredibly convenient and keeps me connected with my family and the rest of the world.",
    keywords: ["Electronic device", "Indispensable tool", "Multiple purposes", "Look up definitions", "Communicate with classmates", "Messaging apps", "Check bus schedules", "Educational apps", "Practice listening skills", "Source of distraction", "Incredibly convenient", "Keep connected", "Smart technology", "Portable", "Search for information", "Stay updated", "High-resolution screen", "Battery life", "Digital age", "Essential item"]
  },
  {
    category: "Objects",
    title: "A Meaningful Gift",
    prompt: "Describe a gift you received that is very meaningful to you.",
    model: "On my graduation from elementary school, my grandfather gave me a beautiful, classic fountain pen. It is made of black resin with gold trim, and my name is engraved on it. This gift is meaningful because my grandfather passed away last year, so the pen serves as a precious keepsake. Whenever I use it to write in my journal, I feel connected to his love and wisdom. It reminds me to work hard and stay honest, just like he always taught me.",
    keywords: ["Gift received", "Meaningful", "Graduation", "Classic fountain pen", "Engraved name", "Passed away", "Precious keepsake", "Write in my journal", "Connected to his love", "Remind someone to", "Work hard", "Stay honest", "Generous present", "Family memory", "Highly valued", "Emotional value", "Take care of it", "Special occasion", "Wisdom", "Express affection"]
  },
  {
    category: "Objects",
    title: "Favorite Clothing",
    prompt: "Describe a piece of clothing you like to wear most.",
    model: "My favorite piece of clothing is an oversized denim jacket that I bought during a vacation last year. It has a slightly faded blue color and a very casual, stylish look. I love wearing it because it is incredibly versatile and goes well with almost any outfit, whether I am wearing a T-shirt or a hoodie. Most importantly, it is extremely comfortable and protects me from the chilly wind on autumn mornings. Wearing it makes me feel confident and relaxed.",
    keywords: ["Piece of clothing", "Oversized denim jacket", "Bought during vacation", "Faded blue color", "Casual look", "Stylish", "Incredibly versatile", "Go well with", "Outfit", "Hoodie", "Extremely comfortable", "Protect from chilly wind", "Autumn mornings", "Feel confident", "Personal style", "Durable material", "Fashion choice", "Practical wear", "Wardrobe favorite", "Everyday clothes"]
  },
  {
    category: "Objects",
    title: "An Interesting Book",
    prompt: "Describe a book that you found interesting or useful.",
    model: "A book that I found highly useful is called Atomic Habits by James Clear. It explains how making tiny changes in our daily routines can lead to massive life improvements over time. I read it during my summer break, and it completely changed how I manage my schedule. Thanks to its practical advice, I managed to build a habit of studying English vocabulary for fifteen minutes every night. It taught me that consistency is the key to achieving any long-term goal.",
    keywords: ["Found highly useful", "Atomic Habits", "Tiny changes", "Daily routines", "Massive improvements", "Over time", "Summer break", "Manage my schedule", "Practical advice", "Build a habit", "English vocabulary", "Every night", "Consistency is key", "Long-term goal", "Life-changing book", "Best-seller", "Easy to understand", "Highly recommended", "Self-improvement", "Productive mindset"]
  },
  {
    category: "Objects",
    title: "A Learning App or Website",
    prompt: "Describe a website or mobile application you use to learn new things.",
    model: "I frequently use Duolingo, a language learning application, to improve my English and explore basic Spanish. The app is designed like a game, where you can earn points and level up by completing quick lessons. This playful setup makes learning grammar and vocabulary highly entertaining rather than boring. It also tracks my daily progress, which motivates me to keep a consistent study streak. It is an amazing educational tool for students to utilize during short breaks.",
    keywords: ["Frequently use", "Language learning application", "Improve English", "Explore basic skills", "Designed like a game", "Earn points", "Level up", "Quick lessons", "Playful setup", "Highly entertaining", "Rather than boring", "Track daily progress", "Consistent study streak", "Educational tool", "Utilize during breaks", "User-friendly interface", "Free interactive lessons", "Expand vocabulary", "Daily notification", "Digital learning"]
  },
  {
    category: "Objects",
    title: "Art or Decoration at Home",
    prompt: "Describe a piece of art or decoration in your home that you like.",
    model: "In our living room, there is a large framed landscape painting hanging on the central wall. It depicts a peaceful countryside scene with green fields, mountains, and a clear blue sky. My parents bought it from a local artist during our trip to Yilan. I love looking at it because the soft colors give me a sense of peace and tranquility whenever I feel stressed out about my studies. It adds a touch of natural beauty and elegance to our living space.",
    keywords: ["Living room", "Framed landscape painting", "Hanging on the wall", "Depict a peaceful scene", "Countryside scene", "Local artist", "Family trip", "Soft colors", "Sense of peace", "Tranquility", "Stressed out about studies", "Add a touch of", "Natural beauty", "Elegance", "Living space", "Interior decoration", "Visual appeal", "Art lover", "Relaxing effect", "Masterpiece"]
  },
  {
    category: "Objects",
    title: "A Traditional Object",
    prompt: "Describe an object that is typical or traditional in your culture.",
    model: "A traditional object in Taiwanese culture is the pineapple cake. It is a famous pastry filled with sweet pineapple paste wrapped in a rich, buttery crust. In Taiwanese Hokkien, the word for pineapple sounds like prosperity arrives, which makes it a highly popular symbol of good luck and fortune. People usually give them as gifts during major festivals, like the Lunar New Year, to wish others success. It represents our warm hospitality and deep cultural heritage.",
    keywords: ["Traditional object", "Taiwanese culture", "Pineapple cake", "Famous pastry", "Rich buttery crust", "Sound like prosperity", "Popular symbol", "Good luck and fortune", "Give as gifts", "Major festivals", "Lunar New Year", "Wish others success", "Warm hospitality", "Deep cultural heritage", "Local delicacy", "Souvenir", "Traditional recipe", "Deeply rooted in", "Bring blessings", "Sweet paste filling"]
  },
  {
    category: "Events and Experiences",
    title: "A Memorable School Trip",
    prompt: "Describe a memorable school trip you took.",
    model: "The most memorable school trip I took was our graduation trip to Kenting last year. We spent three days exploring the beautiful beaches and night markets with our classmates. The highlight of the trip was visiting the national aquarium, where we slept overnight under a giant glass tunnel surrounded by sharks and tropical fish. It was an incredible experience because we stayed up late talking and strengthening our friendships. It was the perfect ending to my junior high school life.",
    keywords: ["Memorable school trip", "Graduation trip", "Spend three days", "Explore beaches", "Night markets", "Highlight of the trip", "National aquarium", "Sleep overnight", "Giant glass tunnel", "Surrounded by sharks", "Tropical fish", "Incredible experience", "Stay up late", "Strengthen friendships", "Perfect ending", "Junior high school life", "Unforgettable memories", "Travel by bus", "Tour guide", "Bond with classmates"]
  },
  {
    category: "Events and Experiences",
    title: "A Festival or Holiday",
    prompt: "Describe a festival or holiday celebration in your country.",
    model: "My favorite holiday celebration in Taiwan is the Mid-Autumn Festival. It is a traditional festival where family members gather together under the full moon. The most popular activities include having an outdoor barbecue, eating sweet mooncakes, and sharing pomelos. Children often wear the pomelo skins as hats for fun. For me, this festival is extremely special because it highlights the cultural value of family reunion, allowing us to catch up and enjoy quality time together.",
    keywords: ["Holiday celebration", "Mid-Autumn Festival", "Traditional festival", "Gather together", "Full moon", "Outdoor barbecue", "Eat mooncakes", "Share pomelos", "Wear pomelo skins", "Extremely special", "Highlight cultural values", "Family reunion", "Catch up", "Enjoy quality time", "Festive atmosphere", "Seasonal food", "Pass down traditions", "Public holiday", "Express love for family", "Joyful occasion"]
  },
  {
    category: "Events and Experiences",
    title: "An Important Accomplishment",
    prompt: "Describe an important accomplishment you achieved.",
    model: "An important accomplishment I achieved was winning first place in our school's English speech contest last semester. Initially, I was terrified of public speaking and had a weak English accent. To prepare, I practiced in front of a mirror every single day for a month and recorded my voice to correct pronunciation errors. Winning the award was an unforgettable moment because it proved that my hard work paid off. It significantly boosted my self-confidence and motivation to master English.",
    keywords: ["Important accomplishment", "Win first place", "Speech contest", "Last semester", "Terrified of public speaking", "Weak accent", "In front of a mirror", "Every single day", "Record my voice", "Correct errors", "Pronunciation", "Unforgettable moment", "Hard work paid off", "Significantly boosted", "Self-confidence", "Motivation to learn", "Master a language", "Overcome fear", "Feel proud of", "Achieve a goal"]
  },
  {
    category: "Events and Experiences",
    title: "A Disagreement",
    prompt: "Describe an event where you had a disagreement with someone and how you solved it.",
    model: "During a group project last month, my classmate and I had a severe disagreement about our presentation topic. He wanted to focus on history, while I preferred technology. We were stuck and the deadline was approaching quickly. To solve this conflict, I suggested that we sit down and list the pros and cons of both ideas. Eventually, we found a creative compromise by presenting the history of modern technology. This experience taught me the importance of active listening and teamwork.",
    keywords: ["Group project", "Severe disagreement", "Presentation topic", "Focus on history", "Prefer technology", "Stuck", "Deadline was approaching", "Solve a conflict", "Suggest an idea", "Pros and cons", "Creative compromise", "Active listening", "Teamwork", "Communication skills", "Find a solution", "Express opinions calmly", "Respect differences", "Reach an agreement", "Work together smoothly", "Valuable lesson"]
  },
  {
    category: "Events and Experiences",
    title: "Helping a Stranger",
    prompt: "Describe a time when you helped a stranger.",
    model: "A few weeks ago, while waiting at a busy train station, I saw an elderly foreign tourist looking confused and staring blankly at a ticket machine. Realizing he couldn't read the Chinese characters, I gathered my courage and approached him in English. I politely asked if he needed assistance and guided him step-by-step to buy the correct train ticket to Hualien. He smiled warmly and thanked me sincerely. Helping him made me feel incredibly proud and proved my English was useful.",
    keywords: ["Busy train station", "Elderly foreign tourist", "Look confused", "Stare blankly", "Ticket machine", "Chinese characters", "Gather my courage", "Approach someone", "Need assistance", "Guide step-by-step", "Smile warmly", "Thank sincerely", "Feel incredibly proud", "Useful language", "Lend a hand", "Act of kindness", "Commute", "Cross cultural communication", "Make someone's day", "Friendly interaction"]
  },
  {
    category: "Events and Experiences",
    title: "A Childhood Memory",
    prompt: "Describe a happy childhood memory.",
    model: "One of my happiest childhood memories is learning how to ride a bicycle with my father at a local park when I was eight years old. Initially, I kept falling off and scraped my knees, which made me want to cry and give up. However, my father stayed patient, held the back of my seat, and kept cheering me on. Suddenly, I noticed he let go and I was riding smoothly by myself! I felt an incredible sense of freedom and pure joy that I will always remember.",
    keywords: ["Childhood memory", "Ride a bicycle", "Local park", "Eight years old", "Keep falling off", "Scrape knees", "Want to cry", "Give up", "Stay patient", "Hold the back of the seat", "Cheer someone on", "Let go", "Ride smoothly", "By myself", "Sense of freedom", "Pure joy", "Precious time", "Support from family", "Overcome a difficulty", "Grow up"]
  },
  {
    category: "Events and Experiences",
    title: "A New Hobby",
    prompt: "Describe a new hobby or activity you tried recently.",
    model: "Recently, I started learning how to cook basic western dishes, like pasta and scrambled eggs, through YouTube tutorials. I decided to try this activity because I want to be independent when I move to Singapore for school. At first, my dishes were either too salty or burnt, but after practicing multiple times, my skills improved significantly. Preparing my own meals gives me a great sense of control and creativity, and it has turned into a deeply relaxing hobby.",
    keywords: ["Tried recently", "New hobby", "Cook basic dishes", "Western food", "YouTube tutorials", "Independent", "Move abroad", "Too salty", "Burnt food", "Practice multiple times", "Improve significantly", "Prepare own meals", "Sense of control", "Creative activity", "Relaxing hobby", "Culinary skills", "Kitchen safety", "Trial and error", "Healthy lifestyle", "Satisfying result"]
  },
  {
    category: "Events and Experiences",
    title: "Adapting to a Sudden Change",
    prompt: "Describe a time when you had to adapt to a sudden change.",
    model: "Two years ago, during the pandemic, our school suddenly shifted entirely to online learning from home. It was a massive change because I had to adapt to using digital platforms like Zoom and Google Classroom overnight. Initially, I struggled with technical glitches and experienced difficulty staying focused without teachers being physically present. To cope, I created a strict daily schedule and set up a quiet study zone in my room. This experience helped me become a highly self-disciplined and adaptable person.",
    keywords: ["Adapt to change", "Sudden change", "Pandemic period", "Shift to online learning", "Digital platforms", "Google Classroom", "Overnight", "Struggle with glitches", "Technical issues", "Experience difficulty", "Stay focused", "Physically present", "Cope with problems", "Create a strict schedule", "Quiet study zone", "Self-disciplined", "Adaptable person", "Virtual classroom", "Independent study", "Overcome challenges"]
  }
];
